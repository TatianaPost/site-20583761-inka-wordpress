<?php
/**
 * Globally-accessible functions
 *
 * @link 		https://deothemes.com
 * @since 		1.0.0
 *
 * @package		Deo_Core
 * @subpackage 	Deo_Core/includes
 */


/**
* Social share icons
*/
function deo_social_sharing_buttons() {
	$output = '';
	$URL = urlencode(get_permalink());
	$title = str_replace( ' ', '%20', get_the_title());
	$thumb = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'full' );

	// Construct sharing URL without using any script
	$twitterURL = 'https://twitter.com/intent/tweet?text=' . $title . '&amp;url=' . $URL;
	$facebookURL = 'https://www.facebook.com/sharer/sharer.php?u=' . $URL;
	$googleURL = 'https://plus.google.com/share?url=' . $URL;
	$linkedInURL = 'https://www.linkedin.com/shareArticle?mini=true&url=' . $URL . '&amp;title=' . $title;
	$pinterestURL = 'https://pinterest.com/pin/create/button/?url=' . $URL . '&amp;media=' . $thumb[0] . '&amp;description=' . $title;
	$pocketURL = 'https://getpocket.com/save?url=' . $URL;
	$emailURL = 'mailto:?subject=' . $title;

	ob_start();


	$social = get_theme_mod( 'deo_share_facebook', true );
	if ( $social ) {
		printf( '<a class="social social-facebook entry__share-social social--colored social--colored-facebook" href="%1$s" target="_blank"><i class="ui-facebook"></i></a>',
			esc_url( $facebookURL )
		);
	}

	$social = get_theme_mod( 'deo_share_twitter', true );
	if ( $social ) {
		printf( '<a class="social social-twitter entry__share-social social--colored social--colored-twitter" href="%1$s" target="_blank"><i class="ui-twitter"></i></a>',
			esc_url( $twitterURL )
		);
	}

	$social = get_theme_mod( 'deo_share_google_plus', true );
	if ( $social ) {
		printf( '<a class="social social-google-plus entry__share-social social--colored social--colored-google" href="%1$s" target="_blank"><i class="ui-google"></i></a>',
			esc_url( $googleURL )
		);
	}

	$social = get_theme_mod( 'deo_share_linkedin', false );
	if ( $social ) {
		printf( '<a class="social social-linkedin entry__share-social social--colored social--colored-linkedin" href="%1$s" target="_blank"><i class="ui-linkedin"></i></a>',
			esc_url( $linkedInURL )
		);
	}

	$social = get_theme_mod( 'deo_share_pinterest', true );
	if ( $social ) {
		printf( '<a class="social social-pinterest entry__share-social social--colored social--colored-pinterest" href="%1$s" target="_blank"><i class="ui-pinterest"></i></a>',
			esc_url( $pinterestURL )
		);
	}

	$social = get_theme_mod( 'deo_share_pocket', true );
	if ( $social ) {
		printf( '<a class="social social-pocket entry__share-social social--colored social--colored-pocket" href="%1$s" target="_blank"><i class="ui-get-pocket"></i></a>',
			esc_url( $pocketURL )
		);
	}

	$social = get_theme_mod( 'deo_share_email', true );
	if ( $social ) {
		printf( '<a class="social social-email entry__share-social social--colored social--colored-email" href="%1$s" target="_blank"><i class="ui-email"></i></a>',
			esc_url( $emailURL )
		);
	}

	$output = ob_get_clean();

	if ( strlen( $output ) ) {
			return sprintf( '<div class="socials socials--nobase entry__share-socials">%1$s</div>', $output );
	}

	return false;
}

/**
* Renders social icons from customizer
*/
function deo_render_social_icons( $type = '', $echo = false ) {
	ob_start();

	$title = ($type == 'text') ? '<span class="social__text">%2$s</span>' : '';
	$social = get_theme_mod( 'deo_socials_settings_facebook', '' );
	if ( is_string( $social ) && strlen( $social ) > 0 ) {    
		printf(
			'<a class="social social-facebook" href="%1$s" title="%2$s" target="_blank" rel="noopener nofollow"><i class="ui-facebook"></i>' . $title . '</a>',
			esc_url( $social ),
			__( 'Facebook', 'deo-core' )
		);
	}

	$social = get_theme_mod( 'deo_socials_settings_twitter', '' );
	if ( is_string( $social ) && strlen( $social ) > 0 ) {
		printf(
			'<a class="social social-twitter" href="%1$s" title="%2$s" target="_blank" rel="noopener nofollow"><i class="ui-twitter"></i>' . $title . '</a>',
			esc_url( $social ),
			__( 'Twitter', 'deo-core' )
		);
	}

	$social = get_theme_mod( 'deo_socials_settings_google_plus', '' );
	if ( is_string( $social ) && strlen( $social ) > 0 ) {
		printf(
			'<a class="social social-google-plus" href="%1$s" title="%2$s" target="_blank" rel="noopener nofollow"><i class="ui-google"></i>' . $title . '</a>',
			esc_url( $social ),
			__( 'Google +', 'deo-core' )
		);
	}

	$social = get_theme_mod( 'deo_socials_settings_instagram', '' );
	if ( is_string( $social ) && strlen( $social ) > 0 ) {
		printf(
			'<a class="social social-instagram" href="%1$s" title="%2$s" target="_blank" rel="noopener nofollow"><i class="ui-instagram"></i>' . $title . '</a>',
			esc_url( $social ),
			__( 'Instagram', 'deo-core' )
		);
	}

	$social = get_theme_mod( 'deo_socials_settings_pinterest', '' );
	if ( is_string( $social ) && strlen( $social ) > 0 ) {
		printf(
			'<a class="social social-pinterest" href="%1$s" title="%2$s" target="_blank" rel="noopener nofollow"><i class="ui-pinterest"></i>' . $title . '</a>',
			esc_url( $social ),
			__( 'Pinterest', 'deo-core' )
		);
	}

	$social = get_theme_mod( 'deo_socials_settings_snapchat', '' );
	if ( is_string( $social ) && strlen( $social ) > 0 ) {
		printf(
			'<a class="social social-snapchat" href="%1$s" title="%2$s" target="_blank" rel="noopener nofollow"><i class="ui-snapchat"></i>' . $title . '</a>',
			esc_url( $social ),
			__( 'Snapchat', 'deo-core' )
		);
	}

	$social = get_theme_mod( 'deo_socials_settings_bloglovin', '' );
	if ( is_string( $social ) && strlen( $social ) > 0 ) {
		printf(
			'<a class="social social-bloglovin" href="%1$s" title="%2$s" target="_blank" rel="noopener nofollow"><i class="ui-bloglovin"></i>' . $title . '</a>',
			esc_url( $social ),
			__( 'Bloglovin', 'deo-core' )
		);
	}

	$social = get_theme_mod( 'deo_socials_settings_blogger', '' );
	if ( is_string( $social ) && strlen( $social ) > 0 ) {
		printf(
			'<a class="social social-blogger" href="%1$s" title="%2$s" target="_blank" rel="noopener nofollow"><i class="ui-blogger"></i>' . $title . '</a>',
			esc_url( $social ),
			__( 'Blogger', 'deo-core' )
		);
	}

	$social = get_theme_mod( 'deo_socials_settings_linkedin', '' );
	if ( is_string( $social ) && strlen( $social ) > 0 ) {
		printf(
			'<a class="social social-linkedin" href="%1$s" title="%2$s" target="_blank" rel="noopener nofollow"><i class="ui-linkedin"></i>' . $title . '</a>',
			esc_url( $social ),
			__( 'Linkedin', 'deo-core' )
		);
	}

	$social = get_theme_mod( 'deo_socials_settings_dribbble', '' );
	if ( is_string( $social ) && strlen( $social ) > 0 ) {
		printf(
			'<a class="social social-dribbble" href="%1$s" title="%2$s" target="_blank" rel="noopener nofollow"><i class="ui-dribbble"></i>' . $title . '</a>',
			esc_url( $social ),
			__( 'Dribbble', 'deo-core' )
		);
	}

	$social = get_theme_mod( 'deo_socials_settings_tumblr', '' );
	if ( is_string( $social ) && strlen( $social ) > 0 ) {
		printf(
			'<a class="social social-tumblr" href="%1$s" title="%2$s" target="_blank" rel="noopener nofollow"><i class="ui-tumblr"></i>' . $title . '</a>',
			esc_url( $social ),
			__( 'Tumblr', 'deo-core' )
		);
	}

	$social = get_theme_mod( 'deo_socials_settings_reddit', '' );
	if ( is_string( $social ) && strlen( $social ) > 0 ) {
		printf(
			'<a class="social social-reddit" href="%1$s" title="%2$s" target="_blank" rel="noopener nofollow"><i class="ui-reddit"></i>' . $title . '</a>',
			esc_url( $social ),
			__( 'Reddit', 'deo-core' )
		);
	}

	$social = get_theme_mod( 'deo_socials_settings_behance', '' );
	if ( is_string( $social ) && strlen( $social ) > 0 ) {
		printf(
			'<a class="social social-behance" href="%1$s" title="%2$s" target="_blank" rel="noopener nofollow"><i class="ui-behance"></i>' . $title . '</a>',
			esc_url( $social ),
			__( 'Behance', 'deo-core' )
		);
	}

	$social = get_theme_mod( 'deo_socials_settings_vkontakte', '' );
	if ( is_string( $social ) && strlen( $social ) > 0 ) {
		printf(
			'<a class="social social-vkontakte" href="%1$s" title="%2$s" target="_blank" rel="noopener nofollow"><i class="ui-vkontakte"></i>' . $title . '</a>',
			esc_url( $social ),
			__( 'Vkontakte', 'deo-core' )
		);
	}

	$social = get_theme_mod( 'deo_socials_settings_slack', '' );
	if ( is_string( $social ) && strlen( $social ) > 0 ) {
		printf(
			'<a class="social social-slack" href="%1$s" title="%2$s" target="_blank" rel="noopener nofollow"><i class="ui-slack"></i>' . $title . '</a>',
			esc_url( $social ),
			__( 'Slack', 'deo-core' )
		);
	}

	$social = get_theme_mod( 'deo_socials_settings_github', '' );
	if ( is_string( $social ) && strlen( $social ) > 0 ) {
		printf(
			'<a class="social social-github" href="%1$s" title="%2$s" target="_blank" rel="noopener nofollow"><i class="ui-github"></i>' . $title . '</a>',
			esc_url( $social ),
			__( 'Github', 'deo-core' )
		);
	}

	$social = get_theme_mod( 'deo_socials_settings_flickr', '' );
	if ( is_string( $social ) && strlen( $social ) > 0 ) {
		printf(
			'<a class="social social-flickr" href="%1$s" title="%2$s" target="_blank" rel="noopener nofollow"><i class="ui-flickr"></i>' . $title . '</a>',
			esc_url( $social ),
			__( 'Flickr', 'deo-core' )
		);
	}

	$social = get_theme_mod( 'deo_socials_settings_youtube', '' );
	if ( is_string( $social ) && strlen( $social ) > 0 ) {
		printf(
			'<a class="social social-youtube" href="%1$s" title="%2$s" target="_blank" rel="noopener nofollow"><i class="ui-youtube"></i>' . $title . '</a>',
			esc_url( $social ),
			__( 'Youtube', 'deo-core' )
		);
	}

	$social = get_theme_mod( 'deo_socials_settings_xing', '' );
	if ( is_string( $social ) && strlen( $social ) > 0 ) {
		printf(
			'<a class="social social-xing" href="%1$s" title="%2$s" target="_blank" rel="noopener nofollow"><i class="ui-xing"></i>' . $title . '</a>',
			esc_url( $social ),
			__( 'Xing', 'deo-core' )
		);
	}

	$social = get_theme_mod( 'deo_socials_settings_vimeo', '' );
	if ( is_string( $social ) && strlen( $social ) > 0 ) {
		printf(
			'<a class="social social-vimeo" href="%1$s" title="%2$s" target="_blank" rel="noopener nofollow"><i class="ui-vimeo"></i>' . $title . '</a>',
			esc_url( $social ),
			__( 'Vimeo', 'deo-core' )
		);
	}

	$output = ob_get_clean();

	if ( strlen( $output ) ) {
		if ( $echo ) {
			printf( '<div class="socials %1$s">%2$s</div>', $type, $output );
		} else {
			return sprintf( '<div class="socials %1$s">%2$s</div>', $type, $output );
		}
	}
	return false;
}


/**
* Save Posts Views
*/
function deo_save_post_views( $postID ) {
	$metaKey = 'deo_post_views';
	$views = get_post_meta( $postID, $metaKey, true );
	$count = ( empty( $views ) ? 0 : $views );
	$count++;
	update_post_meta( $postID, $metaKey, $count );
}