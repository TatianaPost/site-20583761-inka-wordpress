<?php
/**
 * Widget Popular Posts.
 *
 * @package Inka
 */


class Inka_Popular_Posts_Widget extends WP_Widget {

	// setup the widget name, description etc.
	function __construct() {
		$widget_options = array(
			'classname'   => esc_attr( "widget-popular-posts" ),
			'description'  => esc_html__( 'Custom Popular Posts Widget', 'inka' ),
			'customize_selective_refresh' => true
		);
		parent::__construct( 'inka_popular_posts', 'Inka Popular Posts', $widget_options);
	}


	// front-end display of widget
	function widget( $args, $instance ) {

		extract( $args );
		echo $args['before_widget'];

		if ( ! empty( $instance['title'] ) ) {
			echo $args['before_title'] . apply_filters( 'widget_title', $instance['title'] ) . $args['after_title'];
		}

		$total = absint( $instance['total'] );
		$posts_args = array(
			'post_type'      => 'post',
			'posts_per_page' => $total,
			'meta_key'       => 'deo_post_views',
			'orderby'        => 'meta_value_num',
			'order'          => 'DESC',
			'meta_query' => array(
				array(
					'key' => '_thumbnail_id'
				)
			),
		);

		$posts_query = new WP_Query( $posts_args );

		if( $posts_query->have_posts() ) :

			echo '<ul class="widget-popular-posts__list">';
				while( $posts_query->have_posts() ) : $posts_query->the_post();
					?>

					<li>
						<article class="clearfix">

							<!-- Post thumb -->
							<?php if ( has_post_thumbnail() ) : ?>
								<div class="widget-popular-posts__img-holder">
									<a href="<?php the_permalink(); ?>">
										<img src="<?php the_post_thumbnail_url( 'thumbnail' ); ?>" alt="" class="entry__img">
									</a>
								</div>
							<?php endif; ?>

							<div class="widget-popular-posts__entry">
								<?php the_title( sprintf( '<h3 class="widget-popular-posts__entry-title"><a href="%s">', esc_url( get_permalink() ) ), '</a></h3>' ); ?>
								<ul class="widget-popular-posts__entry-meta">
									<?php echo deo_date_meta(); ?>
								</ul>
							</div>
						</article>
					</li>

					<?php

				endwhile;
			echo '</ul>';

		endif;

		echo $args['after_widget'];

	}


	// back-end display of widget
	function form( $instance ) {

		$title = ( ! empty( $instance['title'] ) ? $instance['title'] : esc_html__( 'Popular Posts', 'inka' ) );
		$total = ( ! empty( $instance['total'] ) ? absint( $instance['total'] ) : 3 );

		?>

			<p>
				<label for="<?php echo esc_attr( $this->get_field_id('title') ); ?>"><?php esc_attr_e( 'Title', 'inka' ); ?></label>
				<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>">
			</p>

			<p>
				<label for="<?php echo esc_attr( $this->get_field_id('total') ); ?>"><?php esc_attr_e( 'Number or posts', 'inka' ); ?></label>
				<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'total' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'total' ) ); ?>" type="number" value="<?php echo esc_attr( $total ); ?>">
			</p>

		<?php
	}


	// update of the widget
	function update( $new_instance, $old_instance ) {
		$instance = $old_instance;
		$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
		$instance['total'] = ( ! empty( $new_instance['total'] ) ) ? absint( strip_tags( $new_instance['total'] ) ) : 0;
		return $instance;
	}

}


add_action( 'widgets_init', function() {
	register_widget( 'Inka_Popular_Posts_Widget' );
});