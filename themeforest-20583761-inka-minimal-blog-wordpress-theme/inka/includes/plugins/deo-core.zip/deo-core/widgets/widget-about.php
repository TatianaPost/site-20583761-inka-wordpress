<?php
/**
 * Widget About Me.
 *
 * @package Inka
 */


class Inka_About_Widget extends WP_Widget {

	// setup the widget name, description etc.
	function __construct() {
		$widget_options = array(
			'classname'   => esc_attr( "widget-about text-center" ),
			'description'  => esc_html__( 'About me widget', 'inka' ),
			'customize_selective_refresh' => true
		);
		parent::__construct( 'inka_profile', 'Inka About Me', $widget_options);
	}


	// front-end display of widget
	function widget( $args, $instance ) {

		extract( $args );
		echo $args['before_widget'];

		if ( ! empty( $instance['title'] ) ) {
			echo $args['before_title'] . apply_filters( 'widget_title', $instance['title'] ) . $args['after_title'];
		}

		if ( ! empty( $instance['image_url'] ) ) {
			$alt = get_post_meta( attachment_url_to_postid($instance['image_url']), '_wp_attachment_image_alt', true );
			?>
				<img src="<?php echo esc_url( $instance['image_url'] ); ?>" class="widget-about-img" alt="<?php echo esc_attr( $alt ); ?>">
			<?php
		}

		if ( ! empty( $instance['description'] ) ) {
			printf('<p class="widget-about-text">%s</p>', $instance['description'] );
		}

		if ( ! empty( $instance['signature_url'] ) ) {
			$alt = get_post_meta( attachment_url_to_postid($instance['signature_url']), '_wp_attachment_image_alt', true );
			?>
				<img src="<?php echo esc_url( $instance['signature_url'] ); ?>" alt="<?php echo esc_attr( $alt ); ?>">
			<?php
		}


		echo $args['after_widget'];
	}


	// back-end display of widget
	function form( $instance ) {

		$title = ( ! empty( $instance['title'] ) ? $instance['title'] : esc_html__( 'About Me', 'inka' ) );
		$description = ( ! empty( $instance['description'] ) ? $instance['description'] : esc_html__( 'The most beautiful experience we can have is the mysterious. It is the fundamental emotion.', 'inka' ) );
		$image = ( ! empty( $instance['image_url'] ) ? $instance['image_url'] : '' );
		$image_signature = ( ! empty( $instance['signature_url'] ) ? $instance['signature_url'] : '' );

		?>

			<!-- Title -->
			<p>
				<label for="<?php echo esc_attr( $this->get_field_id('title') ); ?>"><?php esc_attr_e( 'Title', 'inka' ); ?></label>
				<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>">
			</p>

			<!-- Image -->
			<h4><?php esc_attr_e( "Choose your image", 'inka' ); ?></h4>
			<p>
				<img class="deo-image-media" src="<?php if (isset($instance['image_url']) && $instance['image_url'] != '' ) :
						echo esc_url( $instance['image_url'] );
					endif; ?>" style="width:100%;"
				/>
			</p>
			<p>
				<input type="hidden" class="deo-image-hidden-input widefat" name="<?php echo $this->get_field_name( 'image_url' ); ?>" id="<?php echo $this->get_field_id( 'image_url' ); ?>" value="<?php
					if (isset($instance['image_url']) && $instance['image_url'] != '' ) :
						echo esc_url( $instance['image_url'] );
					 endif;
				?>" />
				<input type="button" class="deo-image-upload-button button button-primary" value="<?php esc_attr_e('Choose Image','inka')?>">
				<input type="button" class="deo-image-delete-button button" value="Remove Image">
			</p>

			<!-- Text -->
			<p>
				<label for="<?php echo esc_attr( $this->get_field_id('description') ); ?>"><?php esc_attr_e( 'Description', 'inka' ); ?></label>
				<textarea id="<?php echo esc_attr( $this->get_field_id('description') ); ?>" name="<?php echo esc_attr( $this->get_field_name('description') ); ?>"  class="widefat" rows="5"><?php echo esc_textarea( $instance['description'] ); ?></textarea>
			</p>

			<!-- Signature -->
			<h4><?php esc_attr_e( "Choose your signature image", 'inka' ); ?></h4>
			<p>
				<img class="deo-signature-media" src="<?php if (isset($instance['signature_url']) && $instance['signature_url'] != '' ) :
						echo esc_url( $instance['signature_url'] );
					endif; ?>" style="max-width:100%; display: block;"
				/>
			</p>
			<p>
				<input type="hidden" class="deo-signature-hidden-input widefat" name="<?php echo $this->get_field_name( 'signature_url' ); ?>" id="<?php echo $this->get_field_id( 'signature_url' ); ?>" value="<?php
					if (isset($instance['signature_url']) && $instance['signature_url'] != '' ) :
						echo esc_url( $instance['signature_url'] );
					 endif;
				?>"/>
				<input type="button" class="deo-signature-upload-button button button-primary" value="<?php esc_attr_e('Choose Image','inka')?>">
				<input type="button" class="deo-signature-delete-button button" value="Remove Image">
			</p>

		<?php
	}


	// update of the widget
	function update( $new_instance, $old_instance ) {
		$instance = $old_instance;
		$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
		$instance['description'] = wp_kses_post( $new_instance['description'] );
		$instance['image_url'] = ( ! empty( $new_instance['image_url'] ) ) ? strip_tags( $new_instance['image_url'] ) : '';
		$instance['signature_url'] = ( ! empty( $new_instance['signature_url'] ) ) ? strip_tags( $new_instance['signature_url'] ) : '';
		return $instance;
	}

}


add_action( 'widgets_init', function() {
	register_widget( 'Inka_About_Widget' );
});